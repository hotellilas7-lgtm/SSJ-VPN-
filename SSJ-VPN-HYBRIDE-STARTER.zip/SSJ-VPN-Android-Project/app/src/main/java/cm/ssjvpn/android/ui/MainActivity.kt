package cm.ssjvpn.android.ui

import android.app.Activity
import android.net.VpnService
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import cm.ssjvpn.android.data.AuthorizedProfile
import cm.ssjvpn.android.data.ServerAndProfileRepository
import cm.ssjvpn.android.data.VpnServerConfig
import cm.ssjvpn.android.network.CameroonCarrierDetector
import cm.ssjvpn.android.vpn.VpnTunnelStatus
import cm.ssjvpn.android.vpn.WireGuardTunnelManager
import kotlinx.coroutines.launch
import java.util.UUID

private val MidnightBlue = Color(0xFF070D19)
private val MidnightSurface = Color(0xFF0F1829)
private val ElectricBlue = Color(0xFF0A84FF)
private val SignalOrange = Color(0xFFFF7900)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = ElectricBlue,
                    secondary = SignalOrange,
                    background = MidnightBlue,
                    surface = MidnightSurface
                )
            ) { SsjVpnMainScreen() }
        }
    }
}

@Composable
fun SsjVpnMainScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val tunnelManager = remember { WireGuardTunnelManager.getInstance(context) }
    val repository = remember { ServerAndProfileRepository(context) }
    val carrierDetector = remember { CameroonCarrierDetector(context) }

    val metrics by tunnelManager.metrics.collectAsState()
    val detectedNetwork = remember { carrierDetector.detectCurrentCarrier() }
    var servers by remember { mutableStateOf(repository.loadCustomServers()) }
    var selectedServer by remember { mutableStateOf(servers.firstOrNull()) }
    val clientKeys = remember { repository.getOrCreateClientKeyPair() }
    var elapsedSeconds by remember { mutableLongStateOf(0L) }
    var endpoint by remember { mutableStateOf("") }
    var port by remember { mutableStateOf("51820") }
    var serverName by remember { mutableStateOf("Mon serveur SSJ") }
    var serverPublicKey by remember { mutableStateOf("") }
    var tunnelAddress by remember { mutableStateOf("10.66.10.2/32") }
    var message by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(metrics.connectedSinceEpochMs, metrics.status) {
        while (metrics.status == VpnTunnelStatus.CONNECTED && metrics.connectedSinceEpochMs != null) {
            elapsedSeconds = (System.currentTimeMillis() - (metrics.connectedSinceEpochMs ?: 0L)) / 1000L
            kotlinx.coroutines.delay(1000L)
        }
        if (metrics.status == VpnTunnelStatus.DISCONNECTED) elapsedSeconds = 0L
    }

    fun refreshServers() {
        servers = repository.loadCustomServers()
        if (selectedServer == null || servers.none { it.id == selectedServer?.id }) {
            selectedServer = servers.firstOrNull()
        }
    }

    val startTunnelNow: () -> Unit = {
        val server = selectedServer
        if (server == null) {
            message = "Ajoute d'abord un vrai serveur WireGuard."
        } else {
            scope.launch {
                val privKey = clientKeys.first
                val profile = AuthorizedProfile(
                    id = "manual-carrier",
                    name = detectedNetwork.carrier.displayName,
                    carrierTarget = detectedNetwork.carrier.mccMnc,
                    mtu = detectedNetwork.carrier.optimalMtu
                )
                val result = tunnelManager.connect(
                    server = server,
                    profile = profile,
                    clientPrivateKeyBase64 = privKey,
                    assignedTunnelCidr = tunnelAddress
                )
                message = result.exceptionOrNull()?.localizedMessage
                    ?: "Interface WireGuard démarrée. Vérifie le handshake et l'accès Internet."
            }
        }
    }

    val vpnPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) startTunnelNow()
        else message = "Autorisation VPN refusée."
    }

    val isConnected = metrics.status == VpnTunnelStatus.CONNECTED
    val ringColor by animateColorAsState(
        targetValue = if (isConnected) SignalOrange else ElectricBlue,
        label = "RingColor"
    )

    Column(
        modifier = Modifier.fillMaxSize().background(MidnightBlue)
            .verticalScroll(rememberScrollState()).padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            SsjShieldMark(Modifier.size(42.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("SSJ VPN", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 22.sp)
                Text("${detectedNetwork.carrier.displayName} · ${detectedNetwork.transportLabel}",
                    color = Color(0xFF94A3B8), fontSize = 11.sp)
            }
            Text(metrics.status.name, color = if (isConnected) SignalOrange else ElectricBlue,
                fontWeight = FontWeight.Bold, fontSize = 11.sp)
        }

        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.size(190.dp).clip(CircleShape)
                .background(Brush.radialGradient(listOf(ringColor.copy(alpha = .22f), MidnightSurface)))
                .border(3.dp, ringColor, CircleShape)
                .clickable {
                    if (isConnected || metrics.status == VpnTunnelStatus.CONNECTING) {
                        tunnelManager.disconnectAsync()
                        message = "Déconnexion demandée."
                    } else {
                        if (selectedServer == null) message = "Aucun serveur réel configuré."
                        else {
                            val intent = VpnService.prepare(context)
                            if (intent != null) vpnPermissionLauncher.launch(intent) else startTunnelNow()
                        }
                    }
                }
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(if (isConnected) "DÉCONNECTER" else "CONNECTER",
                    color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text(formatDuration(elapsedSeconds), color = Color(0xFFCBD5E1), fontSize = 14.sp)
            }
        }

        Card(colors = CardDefaults.cardColors(containerColor = MidnightSurface)) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricItem("Adresse du tunnel", metrics.assignedIp)
                MetricItem("Serveur", metrics.activeServer?.name ?: selectedServer?.name ?: "Non configuré")
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    MetricItem("Téléchargement", formatBitrate(metrics.downloadBps))
                    MetricItem("Envoi", formatBitrate(metrics.uploadBps))
                }
                if (metrics.lastError != null) Text(metrics.lastError!!, color = SignalOrange, fontSize = 12.sp)
            }
        }

        Card(colors = CardDefaults.cardColors(containerColor = MidnightSurface)) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Serveur WireGuard", color = Color.White, fontWeight = FontWeight.Bold)
                if (servers.isEmpty()) {
                    Text("Aucun serveur fictif n'est préchargé. Renseigne les données d'un VPS WireGuard que tu contrôles.",
                        color = Color(0xFFCBD5E1), fontSize = 12.sp)
                } else {
                    servers.forEach { server ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = selectedServer?.id == server.id,
                                onClick = { selectedServer = server })
                            Column(Modifier.weight(1f).clickable { selectedServer = server }) {
                                Text(server.name, color = Color.White)
                                Text("${server.endpointHost}:${server.endpointPort}", color = Color(0xFF94A3B8), fontSize = 11.sp)
                            }
                            TextButton(onClick = {
                                repository.deleteServer(server.id)
                                refreshServers()
                            }) { Text("Supprimer", color = SignalOrange) }
                        }
                    }
                }
                HorizontalDivider(color = Color(0xFF263449))
                Text("Ajouter un serveur réel", color = Color.White, fontWeight = FontWeight.SemiBold)
                Text("Clé publique de ce téléphone (à ajouter comme pair sur le VPS) :",
                    color = Color(0xFF94A3B8), fontSize = 11.sp)
                Text(clientKeys.second, color = Color(0xFF8FC4FF), fontSize = 10.sp)
                OutlinedTextField(serverName, { serverName = it }, label = { Text("Nom du serveur") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(endpoint, { endpoint = it }, label = { Text("Adresse IP ou domaine du VPS") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(port, { port = it.filter(Char::isDigit).take(5) }, label = { Text("Port UDP WireGuard") },
                    modifier = Modifier.fillMaxWidth(), singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                OutlinedTextField(serverPublicKey, { serverPublicKey = it.trim() }, label = { Text("Clé publique du serveur") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                OutlinedTextField(tunnelAddress, { tunnelAddress = it.trim() }, label = { Text("Adresse client attribuée (ex. 10.66.10.2/32)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                Button(
                    onClick = {
                        val p = port.toIntOrNull()
                        val candidate = VpnServerConfig(
                            id = UUID.randomUUID().toString(), name = serverName.trim(),
                            city = "Personnalisé", country = "Configuration personnelle",
                            endpointHost = endpoint.trim(), endpointPort = p ?: -1,
                            publicKey = serverPublicKey.trim()
                        )
                        if (!candidate.isUsable() || !tunnelAddress.matches(Regex("""\d{1,3}(\.\d{1,3}){3}/32"""))) {
                            message = "Vérifie le nom, l'adresse, le port, la clé publique WireGuard et l'IP client."
                        } else {
                            runCatching { repository.saveCustomServer(candidate) }
                                .onSuccess {
                                    refreshServers()
                                    selectedServer = candidate
                                    message = "Serveur enregistré. Ajoute aussi la clé publique du client au serveur WireGuard."
                                    endpoint = ""; serverPublicKey = ""
                                }
                                .onFailure { message = it.localizedMessage ?: "Erreur d'enregistrement." }
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("ENREGISTRER LE SERVEUR") }
            }
        }

        if (message != null) {
            Text(message!!, color = Color(0xFFFFB86B), fontSize = 12.sp)
        }
        Text("SSJ VPN ne fournit pas de forfait Internet. Le tunnel nécessite un serveur actif et un accès réseau autorisé.",
            color = Color(0xFF94A3B8), fontSize = 11.sp)
    }
}

@Composable
private fun MetricItem(label: String, value: String) {
    Column(Modifier.padding(vertical = 3.dp)) {
        Text(label, color = Color(0xFF94A3B8), fontSize = 11.sp)
        Text(value, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
    }
}

@Composable
private fun SsjShieldMark(modifier: Modifier = Modifier) {
    androidx.compose.foundation.Canvas(modifier) {
        val w = size.width
        val h = size.height
        val shield = androidx.compose.ui.graphics.Path().apply {
            moveTo(w * .5f, h * .06f); lineTo(w * .92f, h * .22f); lineTo(w * .92f, h * .54f)
            cubicTo(w * .92f, h * .78f, w * .68f, h * .92f, w * .5f, h * .96f)
            cubicTo(w * .32f, h * .92f, w * .08f, h * .78f, w * .08f, h * .54f)
            lineTo(w * .08f, h * .22f); close()
        }
        drawPath(shield, color = ElectricBlue, style = androidx.compose.ui.graphics.drawscope.Stroke(width = 5f))
    }
}

private fun formatDuration(sec: Long): String {
    val h = sec / 3600; val m = (sec % 3600) / 60; val s = sec % 60
    return "%02d:%02d:%02d".format(h, m, s)
}

private fun formatBitrate(bps: Long): String = when {
    bps >= 1_000_000L -> "%.2f Mbps".format(bps / 1_000_000.0)
    bps >= 1_000L -> "%.1f Kbps".format(bps / 1_000.0)
    else -> "$bps bps"
}
