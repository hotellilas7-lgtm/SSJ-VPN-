package cm.ssjvpn.android.network

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

data class AuthorizedPortalResult(
    val portalName: String,
    val url: String,
    val reachable: Boolean,
    val httpCode: Int,
    val latencyMs: Long,
    val requiresDataPlan: Boolean
)

/**
 * Vérifie de manière strictement conforme et transparente si :
 * 1) Un forfait Internet standard est ouvert (aucune interception Captive Portal).
 * 2) Le site officiel de l'opérateur répond à une requête HTTP(S).
 * IMPORTANT : une réponse HTTP 2xx ne prouve jamais que le trafic est gratuit ou zero-rated.
 * Aucun en-tête falsifié (SNI/Host) n'est injecté.
 */
class AuthorizedAccessChecker {

    private val client = OkHttpClient.Builder()
        .connectTimeout(4, TimeUnit.SECONDS)
        .readTimeout(4, TimeUnit.SECONDS)
        .followRedirects(false)
        .build()

    suspend fun verifyOfficialAccess(carrier: CameroonCarrier): List<AuthorizedPortalResult> =
        withContext(Dispatchers.IO) {
            val targets = buildList {
                add("Accès Internet Standard (Forfait Data)" to "https://connectivitycheck.gstatic.com/generate_204")
                when (carrier) {
                    CameroonCarrier.MTN_CAMEROON ->
                        add("Site officiel MTN Cameroun (test HTTP)" to "https://mtn.cm")
                    CameroonCarrier.ORANGE_CAMEROON ->
                        add("Site officiel Orange Cameroun (test HTTP)" to "https://www.orange.cm")
                    CameroonCarrier.CAMTEL_BLUE ->
                        add("Site officiel Camtel Blue (Zero-Rated)" to "https://www.camtel.cm")
                    CameroonCarrier.WIFI_OR_OTHER -> {
                        add("Portail Officiel MTN Cameroun" to "https://mtn.cm")
                        add("Site officiel Orange Cameroun" to "https://www.orange.cm")
                        add("Site officiel Camtel" to "https://www.camtel.cm")
                    }
                }
            }

            targets.map { (title, url) ->
                val start = System.currentTimeMillis()
                try {
                    val req = Request.Builder()
                        .url(url)
                        .get()
                        .header("User-Agent", "SSJ-VPN-Android-ComplianceCheck/1.0")
                        .build()

                    client.newCall(req).execute().use { res ->
                        val rtt = (System.currentTimeMillis() - start).coerceAtLeast(1L)
                        val isCaptiveRedirect = url.contains("generate_204") && res.code != 204
                        AuthorizedPortalResult(
                            portalName = title,
                            url = url,
                            reachable = res.code in 200..399 && !isCaptiveRedirect,
                            httpCode = res.code,
                            latencyMs = rtt,
                            requiresDataPlan = isCaptiveRedirect
                        )
                    }
                } catch (_: Exception) {
                    val rtt = (System.currentTimeMillis() - start).coerceAtLeast(1L)
                    AuthorizedPortalResult(
                        portalName = title,
                        url = url,
                        reachable = false,
                        httpCode = 0,
                        latencyMs = rtt,
                        requiresDataPlan = true
                    )
                }
            }
        }
}
