package cm.ssjvpn.android.data

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.wireguard.crypto.KeyPair
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

@Serializable
data class VpnServerConfig(
    val id: String,
    val name: String,
    val city: String,
    val country: String,
    val endpointHost: String,
    val endpointPort: Int,
    val publicKey: String,
    val presharedKey: String? = null,
    val recommendedMtu: Int = 1380
) {
    fun isUsable(): Boolean =
        name.isNotBlank() &&
        endpointHost.isNotBlank() &&
        endpointPort in 1..65535 &&
        publicKey.matches(Regex("^[A-Za-z0-9+/]{43}=$")) &&
        recommendedMtu in 1280..1420
}

@Serializable
data class AuthorizedProfile(
    val id: String,
    val name: String,
    val carrierTarget: String,
    val mtu: Int,
    val persistentKeepaliveSeconds: Int = 25,
    val dnsServers: List<String> = listOf("1.1.1.1", "9.9.9.9"),
    val blockIpv6Leak: Boolean = true
)

class ServerAndProfileRepository(context: Context) {
    private val json = Json { ignoreUnknownKeys = true }
    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .callTimeout(20, TimeUnit.SECONDS)
        .build()

    private val encryptedPrefs = EncryptedSharedPreferences.create(
        context,
        "ssj_vpn_secure_vault",
        MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun getOrCreateClientKeyPair(): Pair<String, String> {
        val existingPriv = encryptedPrefs.getString("wg_priv_key", null)
        val existingPub = encryptedPrefs.getString("wg_pub_key", null)
        if (!existingPriv.isNullOrBlank() && !existingPub.isNullOrBlank()) {
            return existingPriv to existingPub
        }
        val kp = KeyPair()
        val privBase64 = kp.privateKey.toBase64()
        val pubBase64 = kp.publicKey.toBase64()
        encryptedPrefs.edit()
            .putString("wg_priv_key", privBase64)
            .putString("wg_pub_key", pubBase64)
            .apply()
        return privBase64 to pubBase64
    }

    /** Empty by design: a server must be provisioned and authorized by its owner. */
    fun loadCustomServers(): List<VpnServerConfig> {
        val raw = encryptedPrefs.getString("custom_servers_json", null) ?: return emptyList()
        return runCatching { json.decodeFromString<List<VpnServerConfig>>(raw) }
            .getOrDefault(emptyList())
            .filter { it.isUsable() }
    }

    fun saveCustomServer(server: VpnServerConfig) {
        require(server.isUsable()) { "Configuration serveur invalide." }
        val updated = loadCustomServers().filterNot { it.id == server.id } + server
        encryptedPrefs.edit()
            .putString("custom_servers_json", json.encodeToString(updated))
            .apply()
    }

    fun deleteServer(serverId: String) {
        val updated = loadCustomServers().filterNot { it.id == serverId }
        encryptedPrefs.edit()
            .putString("custom_servers_json", json.encodeToString(updated))
            .apply()
    }

    suspend fun requestLeaseFromBackend(
        backendBaseUrl: String,
        serverId: String,
        profileId: String,
        clientPubKey: String
    ): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            require(backendBaseUrl.startsWith("https://")) {
                "L'URL du backend doit utiliser HTTPS."
            }
            val payload = json.encodeToString(
                LeaseRequest(serverId, profileId, clientPubKey)
            )
            val req = Request.Builder()
                .url("${backendBaseUrl.trimEnd('/')}/api/vpn/connect")
                .post(payload.toRequestBody("application/json".toMediaType()))
                .build()
            httpClient.newCall(req).execute().use { res ->
                if (!res.isSuccessful) error("Erreur Backend HTTP ${res.code}")
                res.body?.string()?.takeIf { it.isNotBlank() }
                    ?: error("Réponse vide du backend.")
            }
        }
    }

    @Serializable
    private data class LeaseRequest(
        val serverId: String,
        val profileId: String,
        val clientPublicKey: String
    )
}
