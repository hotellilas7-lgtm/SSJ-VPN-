package cm.ssjvpn.android

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.wireguard.android.backend.GoBackend

class SsjVpnApplication : Application() {

    lateinit var goBackend: GoBackend
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this
        goBackend = GoBackend(applicationContext)
        createVpnNotificationChannel()
    }

    private fun createVpnNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                VPN_CHANNEL_ID,
                "État du Tunnel SSJ VPN",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Affiche l'état actif du chiffrement WireGuard, l'IP et le débit."
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    companion object {
        const val VPN_CHANNEL_ID = "ssj_vpn_tunnel_channel"
        lateinit var instance: SsjVpnApplication
            private set
    }
}
