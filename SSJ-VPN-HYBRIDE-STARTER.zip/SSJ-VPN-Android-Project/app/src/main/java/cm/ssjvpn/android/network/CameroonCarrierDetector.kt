package cm.ssjvpn.android.network

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.telephony.TelephonyManager

enum class CameroonCarrier(
    val displayName: String,
    val mccMnc: String,
    val optimalMtu: Int,
    val officialSelfCareDomain: String
) {
    MTN_CAMEROON("MTN Cameroun", "624-01", 1380, "https://mtn.cm"),
    ORANGE_CAMEROON("Orange Cameroun", "624-02", 1360, "https://www.orange.cm"),
    CAMTEL_BLUE("Camtel (Blue)", "624-03", 1280, "https://www.camtel.cm"),
    WIFI_OR_OTHER("Wi-Fi / Autre Opérateur", "AUTO", 1380, "https://connectivitycheck.gstatic.com/generate_204")
}

data class DetectedNetworkState(
    val carrier: CameroonCarrier,
    val transportLabel: String,
    val rawMccMnc: String,
    val isValidatedInternet: Boolean,
    val isCaptivePortal: Boolean
)

class CameroonCarrierDetector(private val context: Context) {

    fun detectCurrentCarrier(): DetectedNetworkState {
        val telephony = context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

        val activeNetwork = cm.activeNetwork
        val caps = activeNetwork?.let { cm.getNetworkCapabilities(it) }

        val rawOperator = telephony.networkOperator?.takeIf { it.isNotBlank() }
            ?: telephony.simOperator.orEmpty()
        val opNameLower = telephony.networkOperatorName.orEmpty().lowercase()

        val carrier = when {
            rawOperator.startsWith("62401") || opNameLower.contains("mtn") ->
                CameroonCarrier.MTN_CAMEROON
            rawOperator.startsWith("62402") || opNameLower.contains("orange") ->
                CameroonCarrier.ORANGE_CAMEROON
            rawOperator.startsWith("62403") || opNameLower.contains("camtel") || opNameLower.contains("blue") ->
                CameroonCarrier.CAMTEL_BLUE
            else -> CameroonCarrier.WIFI_OR_OTHER
        }

        val transportLabel = when {
            caps == null -> "Aucun réseau"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi (${carrier.displayName})"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Données Mobiles 4G/LTE"
            else -> "Ethernet / Autre"
        }

        return DetectedNetworkState(
            carrier = carrier,
            transportLabel = transportLabel,
            rawMccMnc = rawOperator.ifBlank { "N/A" },
            isValidatedInternet = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) == true,
            isCaptivePortal = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_CAPTIVE_PORTAL) == true
        )
    }
}
