package cm.ssjvpn.android.vpn

import android.app.PendingIntent
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import androidx.core.app.NotificationCompat
import cm.ssjvpn.android.SsjVpnApplication
import cm.ssjvpn.android.ui.MainActivity
import com.wireguard.android.backend.GoBackend

class SsjVpnService : GoBackend.VpnService() {

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_DISCONNECT) {
            WireGuardTunnelManager.getInstance(applicationContext).disconnectAsync()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }

        val serverName = intent?.getStringExtra(EXTRA_SERVER_NAME) ?: "Passerelle WireGuard"
        val tunnelIp = intent?.getStringExtra(EXTRA_TUNNEL_IP) ?: "Chiffrement actif"
        promoteToForeground(serverName, tunnelIp)

        return super.onStartCommand(intent, flags, startId)
    }

    private fun promoteToForeground(serverName: String, tunnelIp: String) {
        val openUiIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val disconnectIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, SsjVpnService::class.java).apply { action = ACTION_DISCONNECT },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(this, SsjVpnApplication.VPN_CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle("SSJ VPN · $serverName")
            .setContentText("Service VPN actif · état du tunnel vérifiable dans l’application")
            .setOngoing(true)
            .setContentIntent(openUiIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Déconnecter", disconnectIntent)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    override fun onRevoke() {
        // Appelé par Android si l'utilisateur révoque la permission VPN dans les paramètres système
        WireGuardTunnelManager.getInstance(applicationContext).disconnectAsync()
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onRevoke()
    }

    companion object {
        const val NOTIFICATION_ID = 4401
        const val ACTION_DISCONNECT = "cm.ssjvpn.android.ACTION_DISCONNECT"
        const val EXTRA_SERVER_NAME = "extra_server_name"
        const val EXTRA_TUNNEL_IP = "extra_tunnel_ip"
    }
}
