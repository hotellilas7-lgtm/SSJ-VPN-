package cm.ssjvpn.android.vpn

import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import androidx.core.content.ContextCompat
import cm.ssjvpn.android.SsjVpnApplication
import cm.ssjvpn.android.data.AuthorizedProfile
import cm.ssjvpn.android.data.VpnServerConfig
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import com.wireguard.config.InetEndpoint
import com.wireguard.config.InetNetwork
import com.wireguard.config.Interface
import com.wireguard.config.Peer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.InetAddress

enum class VpnTunnelStatus {
    DISCONNECTED,
    CONNECTING,
    CONNECTED,
    RECONNECTING,
    ERROR
}

data class TunnelLiveMetrics(
    val status: VpnTunnelStatus = VpnTunnelStatus.DISCONNECTED,
    val activeServer: VpnServerConfig? = null,
    val assignedIp: String = "Non assignée",
    val rxBytesTotal: Long = 0L,
    val txBytesTotal: Long = 0L,
    val downloadBps: Long = 0L,
    val uploadBps: Long = 0L,
    val connectedSinceEpochMs: Long? = null,
    val reconnectAttempts: Int = 0,
    val lastError: String? = null
)

class WireGuardTunnelManager private constructor(private val appContext: Context) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val backend get() = SsjVpnApplication.instance.goBackend
    private val connectivityManager =
        appContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

    private val _metrics = MutableStateFlow(TunnelLiveMetrics())
    val metrics: StateFlow<TunnelLiveMetrics> = _metrics.asStateFlow()

    private var statsJob: Job? = null
    private var lastActiveConfig: Config? = null
    private var lastServer: VpnServerConfig? = null
    private var userRequestedConnection = false

    private val wireGuardTunnel = object : Tunnel {
        override fun getName(): String = "ssjvpn0"
        override fun onStateChange(newState: Tunnel.State) {
            if (newState == Tunnel.State.DOWN && !userRequestedConnection) {
                _metrics.value = TunnelLiveMetrics(status = VpnTunnelStatus.DISCONNECTED)
            }
        }
    }

    private val networkCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            // Reconnexion transparente lors d'une bascule 4G MTN/Orange/Camtel <-> Wi-Fi
            if (userRequestedConnection && _metrics.value.status == VpnTunnelStatus.RECONNECTING) {
                triggerAutoReconnect()
            }
        }

        override fun onLost(network: Network) {
            if (userRequestedConnection && _metrics.value.status == VpnTunnelStatus.CONNECTED) {
                _metrics.value = _metrics.value.copy(
                    status = VpnTunnelStatus.RECONNECTING,
                    lastError = "Changement de cellule radio détecté, maintien du tunnel..."
                )
                triggerAutoReconnect()
            }
        }
    }

    init {
        val request = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .addCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN)
            .build()
        connectivityManager.registerNetworkCallback(request, networkCallback)
    }

    suspend fun connect(
        server: VpnServerConfig,
        profile: AuthorizedProfile,
        clientPrivateKeyBase64: String,
        assignedTunnelCidr: String
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            require(server.isUsable()) { "Serveur WireGuard non configuré ou invalide." }
            require(assignedTunnelCidr.matches(Regex("""\d{1,3}(\.\d{1,3}){3}/32"""))) {
                "Adresse IPv4 du client invalide."
            }
            userRequestedConnection = true
            _metrics.value = _metrics.value.copy(
                status = VpnTunnelStatus.CONNECTING,
                activeServer = server,
                lastError = null
            )

            val wgConfig = buildStrictWireGuardConfig(
                server = server,
                profile = profile,
                clientPrivateKeyBase64 = clientPrivateKeyBase64,
                assignedTunnelCidr = assignedTunnelCidr
            )

            lastActiveConfig = wgConfig
            lastServer = server

            // Démarrer le service Foreground VpnService avant l'ouverture de l'interface tun0
            val serviceIntent = Intent(appContext, SsjVpnService::class.java).apply {
                putExtra(SsjVpnService.EXTRA_SERVER_NAME, server.name)
                putExtra(SsjVpnService.EXTRA_TUNNEL_IP, assignedTunnelCidr.substringBefore("/"))
            }
            ContextCompat.startForegroundService(appContext, serviceIntent)

            backend.setState(wireGuardTunnel, Tunnel.State.UP, wgConfig)

            val now = System.currentTimeMillis()
            _metrics.value = TunnelLiveMetrics(
                status = VpnTunnelStatus.CONNECTED,
                activeServer = server,
                assignedIp = assignedTunnelCidr.substringBefore("/"),
                connectedSinceEpochMs = now,
                reconnectAttempts = 0,
                lastError = null
            )

            startLiveStatisticsLoop()
            Result.success(Unit)
        } catch (e: Exception) {
            userRequestedConnection = false
            runCatching { backend.setState(wireGuardTunnel, Tunnel.State.DOWN, null) }
            _metrics.value = _metrics.value.copy(
                status = VpnTunnelStatus.ERROR,
                connectedSinceEpochMs = null,
                assignedIp = "Non assignée",
                lastError = "Échec d'établissement du tunnel WireGuard : ${e.localizedMessage}"
            )
            Result.failure(e)
        }
    }

    fun disconnectAsync() {
        userRequestedConnection = false
        statsJob?.cancel()
        scope.launch {
            runCatching {
                backend.setState(wireGuardTunnel, Tunnel.State.DOWN, null)
            }
            _metrics.value = TunnelLiveMetrics(status = VpnTunnelStatus.DISCONNECTED)
        }
    }

    private fun buildStrictWireGuardConfig(
        server: VpnServerConfig,
        profile: AuthorizedProfile,
        clientPrivateKeyBase64: String,
        assignedTunnelCidr: String
    ): Config {
        val effectiveMtu = minOf(server.recommendedMtu, profile.mtu).coerceIn(1280, 1420)

        val interfaceBuilder = Interface.Builder()
            .parsePrivateKey(clientPrivateKeyBase64)
            .addAddress(InetNetwork.parse(assignedTunnelCidr))
            .setMtu(effectiveMtu)

        // Protection anti-fuite DNS : injection exclusive des résolveurs chiffrés dans tun0
        profile.dnsServers.forEach { dnsIp ->
            interfaceBuilder.addDnsServer(InetAddress.getByName(dnsIp))
        }
        // Exclusion de l'application elle-même des boucles de routage socket si requis par GoBackend
        DnsLeakProtector.applyInterfaceHardening(interfaceBuilder)

        val peerBuilder = Peer.Builder()
            .parsePublicKey(server.publicKey)
            .setEndpoint(InetEndpoint.parse("${server.endpointHost}:${server.endpointPort}"))
            .setPersistentKeepalive(profile.persistentKeepaliveSeconds)
            // Capture complète IPv4 + IPv6 pour bloquer toute fuite hors tunnel sur APN Dual-Stack
            .addAllowedIp(InetNetwork.parse("0.0.0.0/0"))

        if (profile.blockIpv6Leak) {
            peerBuilder.addAllowedIp(InetNetwork.parse("::/0"))
        }

        server.presharedKey?.takeIf { it.isNotBlank() }?.let { psk ->
            peerBuilder.parsePreSharedKey(psk)
        }

        return Config.Builder()
            .setInterface(interfaceBuilder.build())
            .addPeer(peerBuilder.build())
            .build()
    }

    private fun startLiveStatisticsLoop() {
        statsJob?.cancel()
        statsJob = scope.launch {
            var prevRx = 0L
            var prevTx = 0L
            var prevTime = System.currentTimeMillis()

            while (isActive && userRequestedConnection) {
                runCatching {
                    val stats = backend.getStatistics(wireGuardTunnel)
                    val now = System.currentTimeMillis()
                    val rx = stats.totalRx()
                    val tx = stats.totalTx()
                    val elapsedSec = ((now - prevTime) / 1000.0).coerceAtLeast(0.5)

                    val downBps = if (prevRx > 0 && rx >= prevRx) ((rx - prevRx) * 8 / elapsedSec).toLong() else 0L
                    val upBps = if (prevTx > 0 && tx >= prevTx) ((tx - prevTx) * 8 / elapsedSec).toLong() else 0L

                    prevRx = rx
                    prevTx = tx
                    prevTime = now

                    _metrics.value = _metrics.value.copy(
                        rxBytesTotal = rx,
                        txBytesTotal = tx,
                        downloadBps = downBps,
                        uploadBps = upBps
                    )
                }
                delay(1000L)
            }
        }
    }

    private fun triggerAutoReconnect() {
        val config = lastActiveConfig ?: return
        scope.launch {
            var attempt = 1
            val maxAttempts = 6
            while (userRequestedConnection && attempt <= maxAttempts) {
                _metrics.value = _metrics.value.copy(
                    status = VpnTunnelStatus.RECONNECTING,
                    reconnectAttempts = attempt
                )
                val result = runCatching {
                    backend.setState(wireGuardTunnel, Tunnel.State.DOWN, null)
                    delay(350L)
                    backend.setState(wireGuardTunnel, Tunnel.State.UP, config)
                }
                if (result.isSuccess) {
                    _metrics.value = _metrics.value.copy(
                        status = VpnTunnelStatus.CONNECTED,
                        lastError = null
                    )
                    return@launch
                }
                val backoffMs = (1500L * (1 shl (attempt - 1))).coerceAtMost(20_000L)
                delay(backoffMs)
                attempt++
            }

            if (userRequestedConnection) {
                _metrics.value = _metrics.value.copy(
                    status = VpnTunnelStatus.ERROR,
                    lastError = "Reconnexion automatique échouée après $maxAttempts tentatives."
                )
            }
        }
    }

    companion object {
        @Volatile
        private var INSTANCE: WireGuardTunnelManager? = null

        fun getInstance(context: Context): WireGuardTunnelManager {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: WireGuardTunnelManager(context.applicationContext).also { INSTANCE = it }
            }
        }
    }
}
