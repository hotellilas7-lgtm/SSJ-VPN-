package cm.ssjvpn.android.vpn

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import com.wireguard.config.Interface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.InetAddress

data class DnsAuditReport(
    val vpnTransportActive: Boolean,
    val activeSystemDnsServers: List<String>,
    val resolvedControlAddress: String?,
    val leakDetected: Boolean
)

object DnsLeakProtector {

    private val trustedResolvers = setOf(
        "1.1.1.1", "1.0.0.1",
        "9.9.9.9", "149.112.112.112",
        "8.8.8.8", "8.8.4.4"
    )

    fun applyInterfaceHardening(builder: Interface.Builder) {
        // Garantit qu'aucun résolveur local non routé ne prenne le pas sur tun0
        // WireGuard GoBackend configure automatiquement VpnService.Builder.addDnsServer()
        // et bloque le trafic DNS hors interface lorsque AllowedIPs contient 0.0.0.0/0 et ::/0.
    }

    suspend fun verifyActiveDnsIntegrity(context: Context): DnsAuditReport = withContext(Dispatchers.IO) {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val activeNetwork = cm.activeNetwork
        val capabilities = activeNetwork?.let { cm.getNetworkCapabilities(it) }
        val linkProperties = activeNetwork?.let { cm.getLinkProperties(it) }

        val isVpn = capabilities?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true
        val dnsList = linkProperties?.dnsServers?.mapNotNull { it.hostAddress } ?: emptyList()

        val resolvedIp = runCatching {
            InetAddress.getByName("cloudflare.com").hostAddress
        }.getOrNull()

        // Une fuite est signalée si le VPN est censé être actif mais qu'un DNS opérateur hors liste chiffrée répond
        val hasUntrustedDns = dnsList.isEmpty() || dnsList.any { it !in trustedResolvers }

        DnsAuditReport(
            vpnTransportActive = isVpn,
            activeSystemDnsServers = dnsList,
            resolvedControlAddress = resolvedIp,
            leakDetected = !isVpn || hasUntrustedDns
        )
    }
}
