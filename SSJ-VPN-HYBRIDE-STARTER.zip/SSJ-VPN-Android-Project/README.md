# SSJ VPN — starter hybride Android + PWA

## Contenu
- `app/` : application Android Kotlin/Jetpack Compose avec intégration WireGuard native.
- `pwa/` : tableau de bord web installable (PWA), stockage local dans le navigateur.
- `.github/workflows/android-build.yml` : workflow GitHub Actions pour compiler un APK debug dans le cloud.
- `backend-gateway/` : script d'installation initiale d'un serveur WireGuard Ubuntu.

## Important : état réel
Ceci est une **base de développement**, pas un service VPN prêt pour la production. Le tableau de bord PWA est un prototype local : il ne pilote pas encore l'application Android, ne possède pas d'API, et ne peut pas établir un tunnel VPN. Android doit utiliser `VpnService`/WireGuard natif. Aucun serveur, compte, clé ou accès gratuit opérateur n'est fourni. Le build APK n'a pas encore été exécuté ni validé sur un appareil.

## Compiler l'APK dans le cloud depuis un téléphone
1. Créer un dépôt GitHub et y importer le contenu de ce dossier (le dossier racine doit contenir `settings.gradle.kts`, `build.gradle.kts` et `app/`).
2. Dans GitHub, ouvrir l'onglet **Actions** et autoriser les workflows si demandé.
3. Lancer **Build SSJ VPN Android APK** avec **Run workflow** (ou pousser un commit sur `main`/`master`).
4. À la fin, télécharger l'artefact `ssj-vpn-debug-apk` dans le résumé du workflow. Il s'agit d'un APK debug pour tests, pas d'une version Play Store signée.

Le workflow utilise Java 17, Android SDK 35 et Gradle 8.9. Si le build échoue, ouvrir les logs Actions et corriger la première erreur Kotlin/Gradle avant de relancer.

## Tester la PWA
Héberger le dossier `pwa/` sur un site HTTPS (ou un serveur local). Ouvrir `index.html` avec Chrome, puis choisir **Ajouter à l'écran d'accueil**. Les fonctionnalités PWA (service worker et installation) nécessitent HTTPS ou localhost. Les données des formulaires restent localement dans le navigateur.

## Serveur WireGuard
1. Obtenir un VPS Ubuntu et exécuter `sudo bash backend-gateway/setup-wireguard-ubuntu.sh`.
2. Ouvrir UDP 51820 dans les pare-feux système et fournisseur.
3. Ajouter la configuration du serveur dans l'application Android et enregistrer le peer client côté serveur.
4. Tester le handshake avec `sudo wg show`.

Ne partagez jamais les clés privées. Un VPN chiffre et route le trafic à travers un serveur; il ne crée pas de connexion mobile et ne rend pas les forfaits MTN, Orange ou Camtel gratuits. N'utiliser que les accès et profils autorisés par les opérateurs.
