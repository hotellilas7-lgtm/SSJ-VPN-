#!/usr/bin/env bash
# SSJ VPN - installation d'une passerelle WireGuard sur Ubuntu 22.04/24.04.
# À exécuter uniquement sur un VPS que vous administrez.
set -Eeuo pipefail

WG_INTERFACE="wg0"
WG_PORT="${WG_PORT:-51820}"
WG_SUBNET_V4="${WG_SUBNET_V4:-10.66.10.1/24}"
PUBLIC_IFACE="$(ip -4 route list default | awk 'NR==1 {print $5}')"

if [[ $EUID -ne 0 ]]; then
  echo "Lancez ce script avec sudo." >&2
  exit 1
fi
if [[ -z "$PUBLIC_IFACE" ]]; then
  echo "Interface Internet introuvable. Vérifiez la route par défaut." >&2
  exit 1
fi

export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y wireguard wireguard-tools iptables

install -d -m 700 /etc/wireguard
umask 077
if [[ ! -s /etc/wireguard/server_private.key ]]; then
  wg genkey | tee /etc/wireguard/server_private.key | wg pubkey > /etc/wireguard/server_public.key
fi
SERVER_PRIV_KEY="$(cat /etc/wireguard/server_private.key)"
SERVER_PUB_KEY="$(cat /etc/wireguard/server_public.key)"

cat >/etc/sysctl.d/99-ssj-vpn.conf <<EOF
net.ipv4.ip_forward=1
EOF
sysctl --system >/dev/null

cat >/etc/wireguard/${WG_INTERFACE}.conf <<EOF
[Interface]
Address = ${WG_SUBNET_V4}
ListenPort = ${WG_PORT}
PrivateKey = ${SERVER_PRIV_KEY}
MTU = 1380
PostUp = iptables -A FORWARD -i %i -j ACCEPT; iptables -A FORWARD -o %i -j ACCEPT; iptables -t nat -A POSTROUTING -o ${PUBLIC_IFACE} -j MASQUERADE
PostDown = iptables -D FORWARD -i %i -j ACCEPT; iptables -D FORWARD -o %i -j ACCEPT; iptables -t nat -D POSTROUTING -o ${PUBLIC_IFACE} -j MASQUERADE
EOF
chmod 600 /etc/wireguard/${WG_INTERFACE}.conf
systemctl enable --now "wg-quick@${WG_INTERFACE}"

echo
echo "WireGuard installé."
echo "Interface réseau : ${PUBLIC_IFACE}"
echo "Port UDP : ${WG_PORT}"
echo "Clé publique du serveur (à saisir dans SSJ VPN) : ${SERVER_PUB_KEY}"
echo
echo "IMPORTANT : ouvrez UDP ${WG_PORT} dans le pare-feu du VPS et du fournisseur."
echo "Ensuite, créez un pair client sur le serveur avec la clé PUBLIQUE du téléphone."
echo "N'exposez jamais /etc/wireguard/server_private.key."
